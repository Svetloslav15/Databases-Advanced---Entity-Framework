﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=(LocalDb)\MSSQLLocalDB;Database=VaporStore;Trusted_Connection=True";
	}
}