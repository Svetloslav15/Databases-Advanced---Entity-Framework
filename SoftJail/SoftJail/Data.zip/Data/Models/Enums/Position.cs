﻿namespace SoftJail.Data.Models.Enums
{
    public enum Position
    {
        Overseer,
        Guard,
        Watcher,
        Labour
    }
}
