﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=(LocalDb)\MSSQLLocalDB;Database=BookShop;Integrated Security=True;";
    }
}
